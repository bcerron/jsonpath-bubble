import { JSONPath } from 'jsonpath-plus';
export { JSONPath };
