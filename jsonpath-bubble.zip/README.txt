INSTRUCCIONES PASO A PASO

1. Ve a https://github.com/new y crea un repositorio llamado `jsonpath-bubble`.

2. Sube todos los archivos contenidos en esta carpeta al nuevo repositorio desde el navegador de GitHub (no necesitas usar la terminal).

3. Una vez subido, accede a tu archivo desde Bubble.io con esta URL:

   https://cdn.jsdelivr.net/gh/<tu-usuario>/jsonpath-bubble@main/jsonpath.min.js

   (Reemplaza <tu-usuario> con tu nombre de usuario real en GitHub)

4. En Bubble, ve a tu plugin y en "Shared Resources → Scripts", añade esa URL.

5. Ya puedes usar `JSONPath.JSONPath(...)` en tus acciones JavaScript.
